import { Layout } from 'core/layouts';

class HorizontalLayout extends Layout {
}

export default HorizontalLayout;
