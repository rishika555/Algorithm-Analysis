import { Layout } from 'core/layouts';

class VerticalLayout extends Layout {
}

export default VerticalLayout;
