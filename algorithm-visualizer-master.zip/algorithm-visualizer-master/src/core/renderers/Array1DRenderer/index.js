import { Array2DRenderer } from 'core/renderers';

class Array1DRenderer extends Array2DRenderer {
}

export default Array1DRenderer;

